#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>

int main(){
	FILE *fp;
	fp=fopen("http.txt","w");
	int client_socket,i;
	char buffer[1024];
	char * httpget = "GET / HTTP/1.1\r\n"
			 "Host: www.google.com\r\n\r\n";
	char ch[100];
	struct sockaddr_in serverAddr;
	socklen_t addr_size;
	struct timeval tv1,tv2;
	double timediff;
  
	client_socket = socket(AF_INET, SOCK_STREAM, 0);
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(8080);
	serverAddr.sin_addr.s_addr = inet_addr("10.24.0.1");


	addr_size = sizeof serverAddr;
	if(connect(client_socket, (struct sockaddr *) &serverAddr, addr_size) != -1){

		printf("Connecting..\n");
	}

	for(i=1;i<=1000;i++){

		gettimeofday(&tv1,NULL);
		send(client_socket, httpget, strlen(httpget),0);
		recv(client_socket, buffer, 1024, 0);
		gettimeofday(&tv2,NULL);
		timediff=(double)((tv2.tv_sec - tv1.tv_sec)*1000000 + (tv2.tv_usec- tv1.tv_usec));
		//printf("The return value is :%s\n",buffer);				
		printf("%d    %f\n",i,timediff);
		fprintf(fp,"%d    %.2f\n",i,timediff);  
	}
		
	return 0;
}
