#include <stdio.h>             //For standard things
#include <stdlib.h>            //malloc
#include <string.h>            //memset
#include <netinet/if_ether.h>  // for ETH_P_ALL
#include <netinet/ip_icmp.h>   //Provides declarations for icmp header
#include <netinet/udp.h>       //Provides declarations for udp header
#include <netinet/tcp.h>       //Provides declarations for tcp header
#include <netinet/ip.h>        //Provides declarations for ip header
#include <sys/socket.h>
#include <arpa/inet.h>

void ProcessPacket(unsigned char *, int);

int sock_raw;
int tcp = 0, udp = 0, icmp = 0, others = 0, igmp = 0, total = 0, i, j;

int main() {
  int saddr_size, data_size;
  struct sockaddr saddr;
  struct in_addr in;
  int t = 0;
  unsigned char *buffer = (unsigned char *)malloc(65536);
  sock_raw = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));

  while (t++ <= 50000) {
    saddr_size = sizeof saddr;
    data_size = recvfrom(sock_raw, buffer, 65536, 0, &saddr, &saddr_size);
    if (data_size < 0) {
      printf("Recvfrom error , failed to get packets\n");
      return 1;
    }
    // Now process the packet
    ProcessPacket(buffer, data_size);
  }

  close(sock_raw);
  printf("\n\nFinished\n");
  return 0;
}
void ProcessPacket(unsigned char *buffer, int size) {
  // Get the IP Header part of this packet
  struct iphdr *iph = (struct iphdr *)(buffer + sizeof(struct ethhdr));
  ++total;
  // printf("%d ",iph->protocol);
  switch (iph->protocol)  // Check the Protocol and do accordingly...
  {
    case 1:  // ICMP Protocol
      ++icmp;
      // PrintIcmpPacket(Buffer,Size);
      break;

    case 2:  // IGMP Protocol
      ++igmp;
      break;

    case 6:  // TCP Protocol
      ++tcp;
      // print_tcp_packet(buffer , size);
      break;

    case 17:  // UDP Protocol
      ++udp;
      //  print_udp_packet(buffer , size);
      break;

    default:  // Some Other Protocol like ARP etc.
      ++others;
      break;
  }
  printf(
      "TCP : %d   UDP : %d   ICMP : %d   IGMP : %d   Others : %d   Total : "
      "%d",
      tcp, udp, icmp, igmp, others, total);
}
